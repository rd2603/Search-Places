import React, { useState, useEffect } from 'react';
import './App.css';
import SearchBox from './components/SearchBox/SearchBox';
import PlacesTable from './components/PlacesTable/PlacesTable';
import Pagination from './components/Pagination/Pagination';
import { fetchPlaces } from './api/placesApi';

function App() {
  const [places, setPlaces] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [query, setQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);

  const searchPlaces = async (query) => {
    setIsLoading(true);
    try {
      console.log('searchPlaces called with query:', query); // Debugging log

      const data = await fetchPlaces(query, currentPage);
      console.log('API response:', data); // Debugging log
      setPlaces(data);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    console.log(currentPage);
    if (query) searchPlaces(query);
  }, [query, currentPage]);

  return (
    <div className="app">
      <SearchBox onSearch={setQuery} />
      <PlacesTable places={places} isLoading={isLoading} />
      <Pagination totalPages={10} currentPage={currentPage} onPageChange={setCurrentPage} />
    </div>
  );
}

export default App;
