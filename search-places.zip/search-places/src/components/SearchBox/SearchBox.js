import React, { useState } from 'react';
import './SearchBox.css';

const SearchBox = ({ onSearch }) => {
  const [query, setQuery] = useState('');

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      console.log('Search triggered for:', query); // Debugging log
      onSearch(query); // Calls the parent's onSearch
    }
  };

  return (
    <div className="search-box">
      <input
        type="text"
        placeholder="Search Places"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        onKeyPress={handleKeyPress}
      />
    </div>
  );
};

export default SearchBox;
