import React from 'react';
import './PlacesTable.css';

const PlacesTable = ({ places, isLoading }) => {
  if (isLoading) {
    return <div className="spinner">Loading...</div>;
  }

  if (!places.length) {
    return <div className="no-result">No result found</div>;
  }

  return (
    <table className="places-table">
      <thead>
        <tr>
          <th>#</th>
          <th>Place Name</th>
          <th>Country</th>
        </tr>
      </thead>
      <tbody>
        {places.map((place, index) => (
          <tr key={place.id}>
            <td>{index + 1}</td>
            <td>{place.city}</td>
            <td>
              <img
                src={`https://flagsapi.com/${place.countryCode}/shiny/16.png`}
                alt={place.country}
              />
              {place.country}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default PlacesTable;
