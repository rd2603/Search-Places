import axios from 'axios';

const url = 'https://wft-geo-db.p.rapidapi.com/v1/geo/cities';
const headers = {
    'x-rapidapi-host': 'wft-geo-db.p.rapidapi.com',
    'x-rapidapi-key': 'c19ab7cf1dmshcfda04a99e2251ep15ac6djsn71ff7eec4d05',
};

// Fetch places based on search query and limit
export const fetchPlaces = async (query, limit) => {

    try {
        const res = await axios
            .get(`${url}?namePrefix=${query}&limit=5&offset=${limit*5}`, { headers })
            .then((response) => {
                return response.data;
            })
            .catch((err) => {
            });
            return res.data;
    } catch (error) {
        console.error("Error fetching data:", error);
        throw error;
    }
};
