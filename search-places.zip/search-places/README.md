GeoDB Cities Search App

Table of Contents
1. Installation
2. Running the Project
3. Folder Structure
4. Components Overview
5. API Overview

